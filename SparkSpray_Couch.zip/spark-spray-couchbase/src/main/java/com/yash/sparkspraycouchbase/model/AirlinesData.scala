package com.yash.sparkspraycouchbase.model

import spray.json.DefaultJsonProtocol

/**
 * Case Class of the domain Airlines
 */
case class Airlines(airlineCompany:String , typeOfAirline:String , name:String , email:String , contactNumber:Long , from:String , to:String)
/**
 * This object is extended by DefaultJsonProtocol as it will be helpful in returning a Airlines class in a JSON Format in response
 * The jsonFormat7() is used here as there are 7 fields in the case class and it can be varied accordingly
 */
object AirlinesData extends DefaultJsonProtocol {
  implicit val airlinesFormat=jsonFormat7(Airlines)
}