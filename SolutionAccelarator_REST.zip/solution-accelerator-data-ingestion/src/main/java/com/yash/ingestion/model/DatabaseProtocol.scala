package com.yash.ingestion.model

import spray.json.DefaultJsonProtocol

case class DBModel(dbDriver:String , dbURL:String , dbTable:String , dbUsername:String , dbPassword:String)
object DatabaseProtocol extends DefaultJsonProtocol {
  implicit val databaseFormat=jsonFormat5(DBModel)
}