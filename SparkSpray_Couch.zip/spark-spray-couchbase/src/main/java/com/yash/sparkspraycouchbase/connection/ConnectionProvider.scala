package com.yash.sparkspraycouchbase.connection

import com.couchbase.client.java.CouchbaseCluster
import org.apache.spark.{SparkContext,SparkConf}

/**
 * This class is providing the emrAddress and bucket name to the inbuilt objects of this class
 * The CouchbaseConnection object is used to configure the cluster and we can get the bucket so that we can perform the remove operation
 * The SparkContextConfig is used to configure the spark configuration
 * @author sushant.varshney
 *
 */
class ConnectionProvider(val emrAddress: String, val bucketNameProvided: String) {
  object CouchbaseConnection {
    val cluster = CouchbaseCluster.create(emrAddress + ":" + 8091)
    val bucket = cluster.openBucket(bucketNameProvided)

  }
  /**
   * We are doing the configuration of Spark.
   * Master is used to set the environment in which it is going to work.
   * Instead of local we can also write local[2].The value in the square brackets indicates the no of cores of your machine
   * The no of cores helps in making the parallelizing process fast.
   * AppName is used to identify our application in the cluster
   * BucketName is the name of the bucket in the couchbase cluster where we are going to store all our data
   */
  object SparkContextConfig {
    private val master = "local[*]"
    private val appName = "spark-spray-starter"
    val conf = new SparkConf().setMaster(master).setAppName(appName).set("com.couchbase.nodes", emrAddress + ":" + 8091).set("com.couchbase.bucket." + bucketNameProvided, "")
    val sc = new SparkContext(conf)
  }
}