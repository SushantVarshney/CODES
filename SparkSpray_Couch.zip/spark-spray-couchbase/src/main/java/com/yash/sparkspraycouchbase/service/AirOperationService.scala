package com.yash.sparkspraycouchbase.service

import com.yash.sparkspraycouchbase.model.Airlines
import spray.http.HttpResponse
import com.yash.sparkspraycouchbase.dao.AirlinesOperationsImpl
import com.yash.sparkspraycouchbase.connection.ConnectionProvider

/**
 * This class is providing all the services that are being used by the client
 * @author sushant.varshney
 *
 */
class AirOperationService(connectionProvider:ConnectionProvider) {
  val airlinesOperationsImpl=new AirlinesOperationsImpl(connectionProvider)
  /**
   * Service method for ticket booking
   * @param airline
   * @return
   */
  def bookTicketsService(airline: Airlines): HttpResponse = {
    airlinesOperationsImpl.bookTickets(airline)
  }
  /**
   * Service method for updating details
   */
  def updateDetailsService(contactNumber:Long, email:String, ticketNumber:String):HttpResponse={
     airlinesOperationsImpl.updateDetails(contactNumber, email, ticketNumber)
  }
  /**
   * Service method for reviewing booking done
   */
  def reviewBookingService(ticketNumber:String):HttpResponse={
     airlinesOperationsImpl.reviewBooking(ticketNumber)
  }
  /**
   * Service method for cancelling booking done
   */
  def cancelBookingService(ticketNumber:String):HttpResponse={
     airlinesOperationsImpl.cancelBooking(ticketNumber)
  }
}