package com.yash.ingestion.controller

import spray.routing.HttpService
import com.yash.ingestion.model._
import com.yash.ingestion.model.DatabaseProtocol._



trait SolutionAcceleratorTrait extends HttpService {

  val routes =
    post {
      path("getDataFromDb"){
        entity(as[DBModel]){ dbModel =>
          {
              
            }
          }
        }
        
      }
    }

}