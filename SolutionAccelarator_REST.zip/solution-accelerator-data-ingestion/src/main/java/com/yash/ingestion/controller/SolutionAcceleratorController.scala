package com.yash.ingestion.controller

import com.yash.ingestion.service.SparkTwitterSource
import com.yash.ingestion.service.SparkDbSource
import com.yash.ingestion.service.SparkMailSource
import com.yash.ingestion.service.ScalaMailSource
import akka.actor.Actor

object SolutionAcceleratorController extends Actor {
 /* val source = args(0).trim()

  if (source != null && source == "twitter") {
    val TwitterProcessor = new SparkTwitterSource
    TwitterProcessor.process()
  } else if (source != null && source == "db") {
    val DBProcessor = new SparkDbSource
    DBProcessor.process()
  } else if (source != null && source == "email") {
    val MailProcessor = new ScalaMailSource
    MailProcessor.process()
  } else {
    println("Please provide a valid supported data source")
  }*/

}