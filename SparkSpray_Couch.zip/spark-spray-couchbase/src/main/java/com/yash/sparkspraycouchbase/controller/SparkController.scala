package com.yash.sparkspraycouchbase.service

import akka.actor.{ Actor, ActorContext }
import com.yash.sparkspraycouchbase.connection.ConnectionProvider
import com.yash.sparkspraycouchbase.controller.SparkControllerTrait
/**
 * This is a class defined to implement the method of SparkControllerTrait
 * we don't implement our route structure directly in the service actor because
 * we want to be able to test it independently, without having to spin up an actor
 * @author sushant.varshney
 *
 */
class SparkController(val emrAddress: String, val bucketNameProvided: String) extends Actor with SparkControllerTrait {
  /**
   *  the HttpService trait defines only one abstract member, which connects the services environment to the enclosing actor or test
   */
  def actorRefFactory: ActorContext = context
  /**
   * this actor only runs our route, but you could add other things here, like request stream processing or timeout handling
   *
   */
  def receive: Actor.Receive = runRoute(sparkRoutes)
}