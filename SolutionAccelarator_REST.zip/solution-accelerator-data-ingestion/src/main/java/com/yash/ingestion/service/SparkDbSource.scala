package com.yash.ingestion.service

import com.yash.ingestion.utils.Helper
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import java.util.HashMap
import java.util.Calendar

class SparkDbSource {
  val Helper = new Helper
  def process(): Unit = {
    val awsAccessKey = Helper.getProperties().getProperty("awsAccessKey")
    val awsSecretKey = Helper.getProperties().getProperty("awsSecretKey")
    val driver = Helper.getProperties().getProperty("driverClass")
    val dbUrl = Helper.getProperties().getProperty("dbUrl")
    val dbtable = Helper.getProperties().getProperty("dbtable")
    val query = Helper.getProperties().getProperty("query")

    val dbMap = new HashMap[String, String]()
    dbMap.put("driver", driver)
    dbMap.put("url", dbUrl)
    dbMap.put("dbtable", "person")
    dbMap.put("partitionColumn", "person_id")
    dbMap.put("lowerBound", "10001")
    dbMap.put("upperBound", "499999")
    dbMap.put("numPartitions", "10")

    val sparkConf = new SparkConf().setAppName("SparkDbSource").setMaster("local[*]").set("spark.driver.allowMultipleContexts", "true")
    val sc = new SparkContext(sparkConf)
    sc.hadoopConfiguration.set("fs.s3n.awsAccessKeyId", awsAccessKey)
    sc.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey", awsSecretKey)
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    val df = sqlContext.read.format("jdbc").options(dbMap).load()
    df.write.mode("APPEND").save(getPrefix)

  }
  def getPrefix(): String = {
    var now = Calendar.getInstance();
    var year = now.get(Calendar.YEAR);
    var month = now.get(Calendar.MONTH) + 1;
    var day = now.get(Calendar.DAY_OF_MONTH);
    var hour = now.get(Calendar.HOUR_OF_DAY);
    var CurrentTimeMillis = System.currentTimeMillis
    var prefix = Helper.getProperties().getProperty("S3Location") + year + "/" + month + "/" + day + "/" + hour + "/" + CurrentTimeMillis
    println("Final Prefix is: " + prefix)
    prefix
  }

}