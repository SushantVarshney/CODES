package com.yash.ingestion.model

import spray.json.DefaultJsonProtocol

case class TwitterModel(consumerKey:String,consumerSecretKey:String,accessToken:String,accessTokenSecret:String)
object TwitterProtocol extends DefaultJsonProtocol{
   implicit val twitterFormat=jsonFormat4(TwitterModel)
  
}
