package com.yash.sparkspraycouchbase.dao

import com.couchbase.client.java.CouchbaseCluster
import com.yash.sparkspraycouchbase.model.Airlines
import com.google.gson.Gson
import com.couchbase.client.java.document.json.JsonObject
import com.couchbase.client.java.document.JsonDocument
import org.apache.spark.{ SparkContext, SparkConf }
import spray.http.HttpResponse
import spray.http.StatusCodes._
import com.couchbase.spark._
import scala.util.Try
import com.yash.sparkspraycouchbase.connection.ConnectionProvider

/**
 * This class is the implementation of the method's define in the AirlinesOperationTrait
 * In this all the functionalities are implemented
 * @author sushant.varshney
 */
class AirlinesOperationsImpl(connectionProvider: ConnectionProvider) extends AirlinesOperationsTrait {
  implicit val arrayOfString = Array("NULL")
  import connectionProvider.CouchbaseConnection._
  import connectionProvider.SparkContextConfig._

  
  /**
   * This is the implementation of updateDetails Method
   * Google gson is used to convert a JSON String into Airlines Class Object
   * As Couchebase store's the data in JSON Document format and JSON Document consists of a key and JSON Object
   * So We are first creating a JSON Object and then creating a JSON Document from it
   * Upsert method is used to update the already existing document identified on the basis of document key
   */
  def updateDetails(contactNumber: Long, email: String, ticketNumber: String): HttpResponse = {
    val documentFetched = getData(ticketNumber)
    try {
      val gson = new Gson
      val airlines = gson.fromJson(documentFetched(0), classOf[Airlines])
      val updatedEmail = email
      val updatedContact = contactNumber
      val jsonObject = JsonObject.create().put("ticketNumber", ticketNumber).put("airlineCompany", airlines.airlineCompany).put("typeOfAirline", airlines.typeOfAirline).put("name", airlines.name).put("email", updatedEmail).put("contactNumber", updatedContact).put("from", airlines.from).put("to", airlines.to)
      val jsonDocument = JsonDocument.create(ticketNumber, jsonObject)
      val result = connectionProvider.CouchbaseConnection.bucket.upsert(jsonDocument)
      HttpResponse(OK, s"Details are successfully updated")
    } catch {
      case e: Exception => HttpResponse(InternalServerError, s"Ticket Number provided is not valid")
    }
  }
  /**
     * CouchbaseConnection.bucket.counter("TicketNumbers", 1, 1).content() 
     * This is used to create a unique key which is going to be inserted into the bucket
     * The first Argument will maintain a seperate document in the couchbase having the latest key provide to the last document inserted
     * That file is not editable
     * The second argument is the starting point of the counter
     * The third argument is to specify by how much we want to increment the key
     * Spark is used in this by the means of sc:SparkContext and the sparkcouchbase connector is providing us the methods like
     * saveToCouchbase
     */
  def bookTickets(airline: Airlines): HttpResponse = {
    val airlineCompany = airline.airlineCompany
    val ticketNumber = airlineCompany + ":" + connectionProvider.CouchbaseConnection.bucket.counter("TicketNumbers", 1, 1).content()
    val jsonObject = JsonObject.create().put("ticketNumber", ticketNumber).put("airlineCompany", airline.airlineCompany).put("typeOfAirline", airline.typeOfAirline).put("name", airline.name).put("email", airline.email).put("contactNumber", airline.contactNumber).put("from", airline.from).put("to", airline.to)
    val jsonDocument = JsonDocument.create(ticketNumber, jsonObject)
    val savedData = connectionProvider.SparkContextConfig.sc.parallelize(Seq(jsonDocument))
    val issaved = Try(savedData.saveToCouchbase()).toOption.fold(false)(x => true)
    issaved match {
      case true => HttpResponse(OK, s"Booking Successful withi ticket number $ticketNumber ")
      case false => HttpResponse(InternalServerError, s"Booking Unsuccessful")
    }
  }
/**
 * The Couchbase connection object which was configured in the connection provider class is used here
 * From that object we are using the bucket because the remove method will be only available through it
 */
  def cancelBooking(ticketNumber: String): HttpResponse = {
    try {
      connectionProvider.CouchbaseConnection.bucket.remove(ticketNumber)
      HttpResponse(OK, s"Your Booking is cancelled ")
    } catch {
      case t: com.couchbase.client.java.error.DocumentDoesNotExistException => HttpResponse(InternalServerError, s"Cancellation Unsuccessful")
    }
  }
  def reviewBooking(ticketNumber: String): HttpResponse = {
    val idAsRDD = connectionProvider.SparkContextConfig.sc.parallelize(Seq(ticketNumber))
    try {
      val fetchedDocument = idAsRDD.couchbaseGet[JsonDocument]().map(_.content.toString).collect
      HttpResponse(OK, s"" + (fetchedDocument(0)))
    } catch {
      case e: Exception => HttpResponse(InternalServerError, s"No Booking is made with this ticket number")
    }
  }
  def getData(ticketNumber: String): Array[String] = {
    val documentId = ticketNumber
    val idAsRDD = connectionProvider.SparkContextConfig.sc.parallelize(Seq(documentId))
    try {
      val documentToUpdate = idAsRDD.couchbaseGet[JsonDocument]().map(_.content.toString).collect
      println("DOCUMENT TO UPDATE " + documentToUpdate(0))
      documentToUpdate
    } catch {
      case e: Exception => arrayOfString
    }
  }
}