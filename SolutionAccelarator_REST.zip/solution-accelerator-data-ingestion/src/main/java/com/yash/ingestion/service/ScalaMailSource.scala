package com.yash.ingestion.service
import com.yash.ingestion.utils.Helper
import java.util.Properties
import javax.mail.Session
import javax.mail.Folder
import javax.mail.Multipart
import javax.mail.internet.MimeBodyPart
import javax.mail.Part
import java.io.File
import org.jsoup.Jsoup
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.ObjectMetadata
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets

class ScalaMailSource {

  val Helper = new Helper
  val awsAccessKey = Helper.getProperties().getProperty("awsAccessKey")
  val awsSecretKey = Helper.getProperties().getProperty("awsSecretKey")
  val mailhost = Helper.getProperties().getProperty("mailhost")
  val mailport = Helper.getProperties().getProperty("mailport")
  val mailusername = Helper.getProperties().getProperty("mailusername")
  /*val mailpassword = Helper.getProperties().getProperty("mailpassword")*/
  val mailpassword = "Iwtg2uasap@a"
  val mailfolder = Helper.getProperties().getProperty("mailfolder")
  /*val isExchangeServer = Helper.getProperties().getProperty("isExchangeServer")*/
  val isExchangeServer = "YES"
  val S3Location = Helper.getProperties().getProperty("S3Location")
  
  val s3client = new AmazonS3Client()
  val meta = new ObjectMetadata();
  def process(): Unit = {
    // Logic to connect for exchange servers and other servers
    if (isExchangeServer.equalsIgnoreCase("no")) {
      connectOtherServer()
    } else if (isExchangeServer.equalsIgnoreCase("yes")) {
      connectExchangeServer()
    } else {
      println("Please provide a valid value to property 'isExchangeServer' in properties file")
    }

  }
  def connectOtherServer(): Unit = {

    // server setting
    val properties = new Properties()
    properties.put("mail.pop3.host", mailhost)
    properties.put("mail.pop3.port", mailport)

    // SSL setting
    properties.setProperty("mail.pop3.socketFactory.class",
      "javax.net.ssl.SSLSocketFactory")
    properties.setProperty("mail.pop3.socketFactory.fallback", "false")
    properties.setProperty("mail.pop3.socketFactory.port",
      String.valueOf(mailport))
    val session = Session.getDefaultInstance(properties);
    // connects to the message store
    val store = session.getStore("pop3");
    store.connect(mailusername, mailpassword);

    // opens the inbox folder
    val folderInbox = store.getFolder("INBOX");
    folderInbox.open(Folder.READ_ONLY);

    // fetches new messages from server
    val arrayMessages = folderInbox.getMessages();
    for (i <- arrayMessages) {
      val fromAddress = i.getFrom();
      val from = fromAddress.head.toString();
      val subject = i.getSubject();
      val sentDate = i.getSentDate().toString();

      val contentType = i.getContentType();
      var messageContent = "";

      // store attachment file name, separated by comma
      var attachFiles = "";

      if (contentType.contains("multipart")) {
        // content may contain attachments
        val multiPart = i.getContent().asInstanceOf[Multipart];
        val numberOfParts = multiPart.getCount();
        for (partCount <- numberOfParts until 0) {
          val part = multiPart
            .getBodyPart(partCount).asInstanceOf[MimeBodyPart];
          if (Part.ATTACHMENT.equalsIgnoreCase(part
            .getDisposition())) {
            // this part is attachment
            val fileName = part.getFileName();
            attachFiles += fileName + ", ";
            part.saveFile(new File("C:\\Users\\anand.agrawal\\Desktop\\Attachments") + File.separator
              + fileName);
          } else {
            // this part may be the message content
            //messageContent = part.getContent().toString();
            // Filtering text contents from html content in body part
            messageContent = Jsoup.parse(part.getContent.toString()).text()
          }
        }

        if (attachFiles.length() > 1) {
          attachFiles = attachFiles.substring(0,
            attachFiles.length() - 2);
        }
      } else if (contentType.contains("text/plain")
        || contentType.contains("text/html")) {
        val content = i.getContent();
        if (content != null) {
          //messageContent = content.toString();
          // Filtering text contents from html content in body part
          messageContent = Jsoup.parse(content.toString()).text()
        }
      }
      // print out details of each message
      val content = from+"\n"+subject+"\n"+sentDate+"\n"+messageContent+"\n"+attachFiles
      val inputstream = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
      meta.setContentLength(content.length);
      s3client.putObject(S3Location, i.getMessageNumber.toString(), inputstream, meta)
      System.out.println("Message #" + i.getMessageNumber);
      System.out.println("\t From: " + from);
      System.out.println("\t Subject: " + subject);
      System.out.println("\t Sent Date: " + sentDate);
      System.out.println("\t Message: " + messageContent);
      System.out.println("\t Attachments: " + attachFiles);
    }

    // disconnect
    folderInbox.close(false);
    store.close();

  }
  def connectExchangeServer(): Unit = {

    val properties = System.getProperties
    properties.setProperty("mail.imap.port", "993")
    val session = Session.getInstance(properties, null)

    val store = session.getStore("imaps")
    // accessing the mail server using the domain user and password
    store.connect("yashmail001.yash.com", "anand.agrawal@yash.com",
      "Apr@2016")
    println("Connected to store")
    // retrieving the inbox folder
    val inbox = store.getFolder("INBOX")
    inbox.open(Folder.READ_ONLY)

    // fetches new messages from server
    val arrayMessages = inbox.getMessages()
    println("Message count in Inbox is: " + arrayMessages.length);
    for (i <- arrayMessages) {
      val fromAddress = i.getFrom();
      val from = fromAddress.head.toString();
      val subject = i.getSubject();
      val sentDate = i.getSentDate().toString();

      val contentType = i.getContentType();
      println("Content type is: "+contentType)
      var messageContent = "";

      // store attachment file name, separated by comma
      var attachFiles = "";

      if (contentType.contains("multipart")) {
        // content may contain attachments
        val multiPart = i.getContent().asInstanceOf[Multipart];
        val numberOfParts = multiPart.getCount();
        var partCount = 0
        for (partCount <- numberOfParts until 0) {
          val part = multiPart
            .getBodyPart(partCount).asInstanceOf[MimeBodyPart];
          if (Part.ATTACHMENT.equalsIgnoreCase(part
            .getDisposition())) {
            // this part is attachment
            val fileName = part.getFileName();
            attachFiles += fileName + ", ";
            part.saveFile(new File("C:\\Users\\anand.agrawal\\Desktop\\Attachments") + File.separator
              + fileName);
          } else {
            // this part may be the message content
            //messageContent = part.getContent().toString();
            // Filtering text contents from html content in body part
            messageContent = Jsoup.parse(part.getContent.toString()).text()
          }
        }

        if (attachFiles.length() > 1) {
          attachFiles = attachFiles.substring(0,
            attachFiles.length() - 2);
        }
      } else if (contentType.contains("text/plain")
        || contentType.contains("text/html")) {
        val content = i.getContent();
        if (content != null) {
          //messageContent = content.toString();
          // Filtering text contents from html content in body part
          messageContent = Jsoup.parse(content.toString()).text()
        }
      }

      // print out details of each message
      println("Message #" + i.getMessageNumber);
      println("\t From: " + from);
      println("\t Subject: " + subject);
      println("\t Sent Date: " + sentDate);
      println("\t Message: " + messageContent);
      println("\t Attachments: " + attachFiles);
    }

    // disconnect
    inbox.close(false);
    store.close();

  }

}