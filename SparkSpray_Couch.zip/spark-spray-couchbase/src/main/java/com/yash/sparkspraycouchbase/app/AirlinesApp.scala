package com.yash.sparkspraycouchbase.app

import spray.can.Http
import akka.io.IO
import akka.actor.{ActorSystem, actorRef2Scala, Props}
import scala.concurrent.duration.DurationInt
import com.yash.sparkspraycouchbase.service.SparkController

/**
 * The whole application is Actor Based
 * Http.Bind method is binding the 8080 port and the ip address in this should be always 0.0.0.0 otherwise it is going to throw Bind Exception
 */
object App {

  def main(args: Array[String]): Unit = {
    // we need an ActorSystem to host our application in
    //If many calls to actor use the same ActorSystem it can be passed as an implicit parameter
    implicit val actorSystem = ActorSystem("spark-services")
    
    /*val service=actorSystem.actorOf(Props(new SparkServices("ec2-54-165-132-74.compute-1.amazonaws.com","AirlinesData")),"spark-services")*/
    val controller = actorSystem.actorOf(Props(new SparkController(args(0), args(1))), "spark-services")
    implicit val timeout = 30 seconds

    // start a new HTTP server on port 8080 with our service actor as the handler
    IO(Http) ! Http.Bind(controller, "0.0.0.0", port = 8080)
  }
}