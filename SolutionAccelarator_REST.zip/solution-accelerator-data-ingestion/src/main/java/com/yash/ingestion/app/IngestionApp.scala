package com.yash.ingestion.app

import spray.can.Http
import akka.io.IO
import akka.actor.{ ActorSystem, Props }
import scala.concurrent.duration.DurationInt

object IngestionApp extends App {
  implicit val actorSystem = ActorSystem("spark-services")
  val controller = actorSystem.actorOf(Props(new SolutionAcceleratorController(args(0), args(1))), "spark-services")
  /*implicit val timeout = 30 seconds*/
    IO(Http) ! Http.Bind(controller, "0.0.0.0", port = 8080)
}