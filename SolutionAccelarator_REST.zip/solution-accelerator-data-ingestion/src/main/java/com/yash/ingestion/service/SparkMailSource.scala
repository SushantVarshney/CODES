package com.yash.ingestion.service

import com.yash.ingestion.utils.Helper
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import java.util.Calendar
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import com.yash.ingestion.utils.CustomMailReceiver

class SparkMailSource {
  val Helper = new Helper
  
  def process(): Unit = {
    val awsAccessKey = Helper.getProperties().getProperty("awsAccessKey")
    val awsSecretKey = Helper.getProperties().getProperty("awsSecretKey")
    val mailhost = Helper.getProperties().getProperty("mailhost")
    val mailport = Helper.getProperties().getProperty("mailport")
    val mailusername = Helper.getProperties().getProperty("mailusername")
    /*val mailpassword = Helper.getProperties().getProperty("mailpassword")*/
    val mailpassword="Iwtg2uasap@a"
    val mailfolder = Helper.getProperties().getProperty("mailfolder")

    val sparkConf = new SparkConf().setAppName("SparkMailSource").setMaster("local[*]").set("spark.driver.allowMultipleContexts", "true")
    val sc = new SparkContext(sparkConf)
    val ssc = new StreamingContext(sparkConf, Seconds(Helper.getProperties().getProperty("batchingInterval").toInt))
    
    ssc.sparkContext.hadoopConfiguration.set("fs.s3n.awsAccessKeyId", awsAccessKey);
    ssc.sparkContext.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey", awsSecretKey);
    
    val stream = ssc.receiverStream(new CustomMailReceiver(mailhost, mailusername, mailpassword, mailport.toInt))
    println(stream)
    stream.repartition(1).foreachRDD { x =>
      if (!x.isEmpty()) {
        println("This is outcome: "+x.toString())
        x.saveAsTextFile(getPrefix)
      }
    }

    // create twitter stream
    ssc.start()
    ssc.awaitTermination()
  }

  def getPrefix(): String = {
    var now = Calendar.getInstance();
    var year = now.get(Calendar.YEAR);
    var month = now.get(Calendar.MONTH) + 1;
    var day = now.get(Calendar.DAY_OF_MONTH);
    var hour = now.get(Calendar.HOUR_OF_DAY);
    var CurrentTimeMillis = System.currentTimeMillis
    var prefix = Helper.getProperties().getProperty("S3Location") + year + "/" + month + "/" + day + "/" + hour + "/" + CurrentTimeMillis
    println("Final Prefix is: " + prefix)
    prefix
  }

}