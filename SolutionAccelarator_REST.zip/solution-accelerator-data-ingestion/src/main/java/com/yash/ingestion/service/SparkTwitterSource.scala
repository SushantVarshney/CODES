package com.yash.ingestion.service

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.streaming.twitter.TwitterUtils
import java.util.Calendar
import org.apache.spark.streaming.Seconds
import org.apache.spark.streaming.StreamingContext
import com.yash.ingestion.utils.Helper

/**
 * @author anand.agrawal
 */
class SparkTwitterSource {

  val Helper = new Helper

  def process(): Unit = {
    val awsAccessKey = Helper.getProperties().getProperty("awsAccessKey")
    val awsSecretKey = Helper.getProperties().getProperty("awsSecretKey")
    val consumerKey = Helper.getProperties().getProperty("consumerKey")
    val consumerSecret = Helper.getProperties().getProperty("consumerSecret")
    val accessToken = Helper.getProperties().getProperty("accessToken")
    val accessTokenSecret = Helper.getProperties().getProperty("accessTokenSecret")

    val keywords = (Helper.getProperties().getProperty("keywords")).split(",")

    System.setProperty("twitter4j.oauth.consumerKey", consumerKey);
    System.setProperty("twitter4j.oauth.consumerSecret", consumerSecret);
    System.setProperty("twitter4j.oauth.accessToken", accessToken);
    System.setProperty("twitter4j.oauth.accessTokenSecret", accessTokenSecret);

    val filters = new Array[String](1)

    filters(0) = "cricket"

    val sparkConf = new SparkConf().setAppName("SparkTwitterSource").setMaster("local[*]").set("spark.driver.allowMultipleContexts", "true")
    val sc = new SparkContext(sparkConf)

    val ssc = new StreamingContext(sparkConf, Seconds(Helper.getProperties().getProperty("batchingInterval").toInt))

    ssc.sparkContext.hadoopConfiguration.set("fs.s3n.awsAccessKeyId", awsAccessKey);
    ssc.sparkContext.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey", awsSecretKey);

    // create twitter stream
    val stream = TwitterUtils.createStream(ssc, None, keywords)
    stream.repartition(1).foreachRDD { x =>
      if (!x.isEmpty()) {
        x.saveAsTextFile(getPrefix)
      }
    }
    ssc.start()
    ssc.awaitTermination()
  }

  def getPrefix(): String = {
    var now = Calendar.getInstance();
    var year = now.get(Calendar.YEAR);
    var month = now.get(Calendar.MONTH) + 1;
    var day = now.get(Calendar.DAY_OF_MONTH);
    var hour = now.get(Calendar.HOUR_OF_DAY);
    var CurrentTimeMillis = System.currentTimeMillis
    var prefix = Helper.getProperties().getProperty("S3Location") + year + "/" + month + "/" + day + "/" + hour + "/" + CurrentTimeMillis
    println("Final Prefix is: " + prefix)
    prefix
  }
}