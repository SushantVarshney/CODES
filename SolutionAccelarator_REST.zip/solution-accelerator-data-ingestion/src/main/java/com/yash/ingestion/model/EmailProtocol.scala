package com.yash.ingestion.model

import spray.json.DefaultJsonProtocol

case class EmailModel(hostType:String,mailPort:Int,username:String,password:String,mailFolder:String,isExchangeServer:String)
object EmailProtocol extends DefaultJsonProtocol {
  implicit val emailFormat=jsonFormat6(EmailModel)
  
}