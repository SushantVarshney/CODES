package com.yash.ingestion.utils

import java.util.Properties

import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.receiver.Receiver

import javax.mail.Folder
import javax.mail.MessagingException
import javax.mail.NoSuchProviderException
import javax.mail.Session

class CustomMailReceiver(host: String, user: String, password: String, port: Int)
  extends Receiver[String](StorageLevel.MEMORY_AND_DISK_2) {

  def onStart() {
    // Start the thread that receives data over a connection
    new Thread("Socket Receiver") {
      override def run() { receive() }
    }.start()
  }

  def onStop() {
   // There is nothing much to do as the thread calling receive()
   // is designed to stop by itself isStopped() returns false
  }

  /** Create a socket connection and receive data until receiver is stopped */
  private def receive() {
      try {

      //create properties field
      val properties = new Properties
      properties.put("mail.pop3.host", host);
      properties.put("mail.pop3.port", "995");
      properties.put("mail.pop3.starttls.enable", "true");
      val emailSession = Session.getDefaultInstance(properties);
  
      //create the POP3 store object and connect with the pop server
      val storejavaxmail = emailSession.getStore("pop3s");

      storejavaxmail.connect(host, user, password);

      //create the folder object and open it
      val emailFolder = storejavaxmail.getFolder("INBOX");
      emailFolder.open(Folder.READ_ONLY);

      // retrieve the messages from the folder in an array and print it
      val messages = emailFolder.getMessages();
      println("messages.length---" + messages.length);
      var count=0
      for (i <-messages) {
         println("---------------------------------");
         println("Email Number " + (count + 1));
         println("Subject: " + i.getSubject());
         println("From: " + i.getFrom().head.toString());
         println("Text: " + i.getContent());
         store(i.getContent().toString())
      }

      //close the store and folder objects
      emailFolder.close(false);
      storejavaxmail.close();

      }
     catch{
     case nspe: NoSuchProviderException => nspe.printStackTrace()
     case me: MessagingException => me.printStackTrace()  
     case e: Exception => e.printStackTrace()
     }
     
   }
}
// scalastyle:on println