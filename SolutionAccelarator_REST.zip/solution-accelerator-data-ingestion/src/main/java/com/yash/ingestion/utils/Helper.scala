package com.yash.ingestion.utils

import java.io.IOException
import java.io.InputStream
import java.net.URL
import java.net.URLConnection
import java.util.Properties
//remove if not needed
import scala.collection.JavaConversions._

/**
 * @author anand.agrawal
 */
class Helper {
  private var properties: Properties = _
  
   def getProperties(): Properties = {
    if (properties == null) {
      var input: InputStream = null
      try {
        val url = new URL("https://s3.amazonaws.com/anand-agrawal/Solution-Accelerator/configuration/solution-accelerator-configuration.properties")
        val conn = url.openConnection()
        input = conn.getInputStream
        properties = new Properties()
        properties.load(input)
      } catch {
        case e: IOException => e.printStackTrace()
      }
    }
    properties
  }
}