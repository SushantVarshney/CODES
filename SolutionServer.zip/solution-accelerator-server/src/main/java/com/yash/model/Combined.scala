package com.yash.model

 class Combined{
  var database:Database=_
  var aws:AWS=_
  var email:Email=_
  var cluster:Cluster=_
  var twitter:Twitter=_
  var hdfs:HDFS=_
}
