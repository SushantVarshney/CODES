package com.yash.sparkspraycouchbase.controller

import spray.routing.HttpService
import com.couchbase.spark._
import spray.http._
import spray.routing.Directive.pimpApply
import com.yash.sparkspraycouchbase.model._
import com.yash.sparkspraycouchbase.model.AirlinesData._
import spray.httpx.SprayJsonSupport.sprayJsonUnmarshaller
import spray.json._
import play.api.libs.json.Json._
import com.yash.sparkspraycouchbase.dao.AirlinesOperationsImpl
import com.yash.sparkspraycouchbase.service.AirOperationService
import com.yash.sparkspraycouchbase.connection.ConnectionProvider

/**
 * We have made a trait here so that we can define all the path's here and later on it can be used by another classes
 * And this trait extends HttpService because after extending this only the routes can be defined
 * @author sushant.varshney
 */
trait SparkControllerTrait extends HttpService {
  val emrAddress: String
  val bucketNameProvided: String
  val connectionProvider = new ConnectionProvider(emrAddress, bucketNameProvided)
  val airOperationService = new AirOperationService(connectionProvider)

  /**
   * These are all the url mapping
   * As Spray is known to make a restful web service so by these routes we are able to make a restful webservice.
   * The path here are used to define the url mapping
   * entity(as[RequestBody]) can be related as the @RequestBody annotation in Spring.
   * The complete method is mandatory to be defined as it defines that in which way this url is going to respond if it is being requested
   * Couchebase supports JsonDocuments which are a combination of a Key and a JSONObject
   * So to store the data we are receiving we have to convert it into a JSON Document.
   * sc.parallelize is used to make RDD from the data.
   * saveToCouchbase is the method which is provided by the Spark Couchbase connector
   * After inserting it will create options by using .toOption() method and after that we are matching true or false
   * HttpResponse will send the response back to the client
   * Similarly couchBaseGet[FormatClass] is going to load all the JSONdocuments into RDD and FormatClass  can be anything you want like JSONDocument,RawJSONDocument
   * Segment in the url is used as it accepts String type values coming in the url.
   * We can use it for everyformat but we can also restrict the user by using IntNumber(if you want only a Integer in the url) instead of Segment and etc.
   *
   */
  val sparkRoutes =
    //This is a POST type request
    post {
      //In path we define the URL by which we are going to make a call
      path("bookTicket") {
        //Entity is used to get a object which we are sending with the post request and the "as" keyword tells that which type of object we are going to receive
        entity(as[Airlines]) { airline =>
          {
            //This is used to send the response in JSON format
            respondWithMediaType(MediaTypes.`application/json`) {
              //In complete we write our logic we are going to do when the request comes and it always must have some return value it can be of any type
              complete {
                //From here we are calling the method that is present in the service layer.
                airOperationService.bookTicketsService(airline)
              }
            }
          }
        }
      }

    } ~
      path("updateBookingDetails" / "contactNumber" / LongNumber / "email" / Segment / "ticketNumber" / Segment) { (contactNumber: Long, email: String, ticketNumber: String) =>
        //This is a GET Type request
        get {
          //This is used to send the response in JSON format
          respondWithMediaType(MediaTypes.`application/json`) {
            //In complete we write our logic we are going to do when the request comes and it always must have some return value it can be of any type
            complete {
              //From here we are calling the method that is present in the service layer.
              airOperationService.updateDetailsService(contactNumber, email, ticketNumber)
            }
          }
        }
      } ~
      path("reviewBooking" / "ticketNumber" / Segment) { (ticketNumber: String) =>
        get {
          respondWithMediaType(MediaTypes.`application/json`) {
            complete {
              airOperationService.reviewBookingService(ticketNumber)
            }
          }
        }
      } ~
      path("cancelBooking" / "ticketNumber" / Segment) { (ticketNumber: String) =>
        get {
          respondWithMediaType(MediaTypes.`application/json`) {
            complete {
              airOperationService.cancelBookingService(ticketNumber)
            }
          }
        }
      }
}