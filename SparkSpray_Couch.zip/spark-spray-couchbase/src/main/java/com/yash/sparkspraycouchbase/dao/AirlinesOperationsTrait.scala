package com.yash.sparkspraycouchbase.dao

import com.yash.sparkspraycouchbase.model.Airlines
import org.apache.spark.SparkContext
import spray.http.HttpResponse

/**
 * Handles the CRUD Operations and other Read operations for Airlines
 * @author sushant.varshney
 */
trait AirlinesOperationsTrait {
  /**
 * Handles the functionality of updating details after booking is made
 */
  def updateDetails(contactNumber: Long, email: String, ticketNumber: String): HttpResponse
  /**
   * Handles the functionality for Ticket booking.
   * @param airline
   * @return
   */
  def bookTickets(airline: Airlines): HttpResponse
/**
 * Handles the functionality of cancellation of the ticket
 */
  def cancelBooking(ticketNumber: String): HttpResponse
/**
 * Handles the functionality of reviewing your booking
 */
  def reviewBooking(ticketNumber: String): HttpResponse
/**
 * This method is internally used by updateDetails Method
 */
  def getData(ticketNumber: String): Array[String]
}